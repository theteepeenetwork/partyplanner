<?= $this->include('header') ?>

<style>
    .basket-item-thumb {
        width: 72px;
        height: 72px;
        object-fit: cover;
        border-radius: 8px;
        flex-shrink: 0;
    }
    .basket-item-thumb--placeholder {
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--surface-warm, #f1ece4);
        border: 1px solid rgba(0, 0, 0, 0.06);
    }
</style>

<main class="page-main">
<div class="dashboard-wrapper">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="mb-0">Event Basket</h3>
                <p class="text-muted mb-0"><?= esc($event['title']) ?> — <?= !empty($event['date']) ? date('d M Y', strtotime($event['date'])) : '' ?></p>
            </div>
            <a href="/browse-services" class="btn btn-outline-primary"><i class="fas fa-plus me-1"></i>Add More Services</a>
        </div>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('info')): ?>
            <div class="alert alert-info"><?= esc(session()->getFlashdata('info')) ?></div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <?php if (!empty($basketItems)): ?>
            <?php foreach ($basketItems as $item): ?>
                <div class="dash-card mb-3">
                    <div class="row align-items-center">
                        <div class="col-md-7">
                            <div class="d-flex align-items-start">
                                <?php if (!empty($item['thumbnail_path'])): ?>
                                    <img src="<?= base_url($item['thumbnail_path']) ?>"
                                         alt="<?= esc($item['service_title']) ?>"
                                         class="basket-item-thumb me-3">
                                <?php else: ?>
                                    <div class="basket-item-thumb basket-item-thumb--placeholder me-3">
                                        <i class="fas fa-concierge-bell text-muted"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1"><?= esc($item['service_title']) ?></h6>
                                    <div class="text-muted small">
                                        <i class="fas fa-store me-1"></i><?= esc($item['vendor_name']) ?>
                                        <?php if (!empty($item['option_label'])): ?>
                                            <span class="ms-2"><i class="fas fa-tag me-1"></i><?= esc($item['option_label']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($item['service_description'])): ?>
                                        <p class="small text-muted mt-1 mb-0"><?= esc(substr($item['service_description'], 0, 100)) ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if (!empty($item['quote_detail']['lines'])): ?>
                                <div class="mt-2 small">
                                    <div class="text-muted fw-semibold mb-1">Quote breakdown</div>
                                    <ul class="mb-0 ps-3">
                                        <?php foreach ($item['quote_detail']['lines'] as $line): ?>
                                            <li class="d-flex justify-content-between gap-2">
                                                <span><?= esc($line['label'] ?? '') ?></span>
                                                <span>£<?= number_format((float) ($line['amount'] ?? 0), 2) ?></span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                    <?php if (isset($item['quote_detail']['distance_km']) && $item['quote_detail']['distance_km'] !== null): ?>
                                        <div class="text-muted mt-1">Road distance (approx.): <?= esc($item['quote_detail']['distance_km']) ?> km</div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-3 text-md-end mt-2 mt-md-0">
                            <?php if (($item['package_name'] ?? '') === 'Price on request' || ((float) $item['estimated_total'] <= 0 && (float) $item['deposit_amount'] <= 0)): ?>
                                <div class="fw-bold text-primary">Price on request</div>
                                <div class="small text-muted">The supplier will send a quote</div>
                            <?php else: ?>
                                <div class="fw-bold text-primary">£<?= number_format($item['estimated_total'], 2) ?></div>
                                <div class="small text-muted">Deposit: £<?= number_format($item['deposit_amount'], 2) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2 text-md-end mt-2 mt-md-0">
                            <a href="/event/basket/remove/<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Remove this service?');">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Totals -->
            <div class="dash-card bg-light">
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Estimated Total</span>
                            <span class="fw-bold">£<?= number_format($totalEstimated, 2) ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span class="text-muted">Deposit Due Today (15%)</span>
                            <span class="fw-bold text-primary">£<?= number_format($totalDeposit, 2) ?></span>
                        </div>
                    </div>
                    <div class="col-md-6 text-md-end mt-3 mt-md-0 d-flex align-items-center justify-content-end">
                        <a href="/event/checkout/<?= $event['id'] ?>" class="btn btn-success btn-lg">
                            <i class="fas fa-lock me-1"></i>Proceed to Checkout
                        </a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="dash-card text-center py-5">
                <i class="fas fa-shopping-basket fa-3x text-muted mb-3"></i>
                <h5>Your basket is empty</h5>
                <p class="text-muted">Browse services and add them to this event.</p>
                <a href="/browse-services" class="btn btn-primary">Browse Services</a>
            </div>
        <?php endif; ?>
    </div>
</div>
</main>

<?= $this->include('footer') ?>
